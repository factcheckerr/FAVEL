There are three folders, one for each dataset:
	- BPDP 22
	- FactBench Mix 22
	- FaVEL-DS 22

In each folder you can find the following structure:
	+ input : This folder has the training and testing split as TSV files that serves as an input to FAVEL's machine learning algorithm, the ground truth is in the column "truth"
	+ single : This folder has the single-approaches scores for the testing split as reified statements in accordance to reified folder
	+ reified : This folder has the reified statements that are also uploaded to GERBIL
	+ ${dataset_name}_ensemble_score_test.nt : Output of the favel system for the testing split, you can use it directly to check the performance against the datasets uploaded in https://gerbil-kbc.aksw.org/gerbil/config
	+ ${dataset_name}_ensemble_score_test_no_esther.nt : Same as the previous file, but with ESTHER removed from the input
	+ model_backup : This folder has the evaluation files created by the FaVEL system, they are pickle files and can be loaded with automl = pickle.load(open("classifier.pkl",'rb'))
